README for Christi Hagen's p1:

In p1.js I was able to get a bit more comfortable with javascript and make something cool!
In this assignment, I created a webpage that has a traditional slider puzzle where the 
number of tiles and the picture displayed is randomized each time the page is opened. 
Additionally, there is a Move Count, so you can see how good or bad you are!
I had trouble running across examples for things that were talking about CSS. Will we be 
talking about CSS soon? I hope so! I really enjoyed programming this, and I hope the next 
assignment will be fun as well.
 
To run: open Chrome with the HTML file p1.html. 
As far as I can tell, everything works as expected.

resources I used:
http://www.w3schools.com/ for everything from parseFloat() to div attributes
stackoverflow.com for nearly all my troubles, especially for html layout this time
http://www.sitepoint.com/forums/showthread.php?979125-How-to-count-the-number-of-times-a-button-is-clicked
for help on move counter