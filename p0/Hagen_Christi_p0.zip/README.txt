README for Christi Hagen's p0:

In p0.js I wrote several small functions to get used to javascript. 
To run: open Chrome with the HTML file p0.html. 
NOTE: I printed all the results from the functions' test 
cases to the webpage itself.

Also, as far as I can tell, everything works as expected.

resources I used:
http://www.quirksmode.org/js/strings.html for looking into concatenation.
http://www.w3schools.com/ for syntax, semantics, HTML DOM stuff, & other basics
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/isArray for testing the type of an array

