README for Christi Hagen's p2 (aka doodle):

This was a difficult assignment for me. I learned a lot about how drawing works and inheritance, though. 

Not everything works:

	- rotation does not work. I even got sick over staying up late working on it, but I 	
	just had to turn in the project, so it remains unavailable.
	
	- note the "/000" comment in doodle-library.js. This mentions how I discovered as I was looking things over 
	that for the primitives-test file to work, commenting context.clip() is necessary. I could not figure a way 	
	to make this work, but since I am already up so late, I had to leave it as is. What this means is that if it 
	is left commented, the primitives test works, but the containers test image doesn't get clipped. If you 
	comment it out, then the containers test image is clipped as desired, but the primitives test images are 
	clipped out.

 
To run doodle.js: open Chrome with the HTML file doodle.html. 
Note: I included the font I used (Distant Galaxy) .ttf file in case it doesn't show up for you.
As far as I can tell, everything works in doodle.js as expected.

resources I used:
http://www.w3schools.com/ 
www://stackoverflow.com
These two sites exclusively, actually. Other places I looked, ie forums, generally were not much help.

I didn't use any help for my doodle.